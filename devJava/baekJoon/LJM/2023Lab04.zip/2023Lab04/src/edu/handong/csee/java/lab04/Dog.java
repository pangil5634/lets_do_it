package edu.handong.csee.java.lab04;

public class Dog extends Animal {
    private int dogGum;

    public int getDogGum() {
        return dogGum;
    }

    public void setDogGum(int dogGum) {
        this.dogGum = dogGum;
    }

}
