package edu.handong.csee.java.lab04;

public class Cat extends Animal {
    private int countOfChew;

    public int getCountOfChew() {
        return countOfChew;
    }

    public void setCountOfChew(int countOfChew) {
        this.countOfChew = countOfChew;
    }

}
